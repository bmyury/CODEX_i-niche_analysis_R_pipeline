library(doParallel)
library(foreach)
library(deldir)


tissues=unique(essentialfulldata[,3])

cl <- makeCluster(12)
registerDoParallel(cl)
re<-foreach(i = 1:length(tissues),.packages = "deldir")%dopar%{

setwd("D:/mPDAC_CODEX/2019Jan15_mPDAC_clustering/analysis/niche_analysis")
sub=essentialfulldata[essentialfulldata[,3]==tissues[i],]

vtess=deldir(sub[,4],sub[,5])
result=vtess$delsgs
a=apply(result,1,function(x){paste(x[1],x[2],sep="__")})
b=apply(result,1,function(x){paste(x[3],x[4],sep="__")})
result[,7]=a
result[,8]=b
colnames(result)[c(7,8)]=c("cell1ID","cell2ID")
resultannot1=merge(result,sub,by.x="cell1ID",by.y="XYcellid")
resultannot2=merge(resultannot1,sub,by.x="cell2ID",by.y="XYcellid") 
selectedcolsresultannot2=resultannot2[,c(3,4,5,6,14,20)]
colnames(selectedcolsresultannot2)[c(5,6)]=c("cell1type","cell2type")
selectedcolsresultannot2=rbind(selectedcolsresultannot2,setNames(selectedcolsresultannot2,c( "x2","y2","x1","y1","cell2type","cell1type")))
write.table(selectedcolsresultannot2,file=paste(tissues[i],"Rdelaun.csv",sep="_"),row.names = FALSE,col.names = TRUE,quote = FALSE,sep = ",")
  
}
stopCluster(cl)