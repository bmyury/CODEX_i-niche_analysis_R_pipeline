#this script creates a file where each cell corresponds to a line 
# and columns list number of neighbors of a particular type for that cell

# loading libraries
library(reshape)


myFile = file.choose()
dira=dirname(myFile)
setwd(dira)

files=list.files(dira)

for (z in 1:length(files))
{
  if(grepl('^reg.*Rdelaun.csv$',files[z]))
  {
    print(z)
    
    #reading input file
    input <- read_csv(files[z])
    
    #preparing input file for making a pivot table
    X=as.data.frame(list(rep(1, nrow(input))))
    inputplus=cbind(input,X)
    
    pivot <- cast(inputplus, cell1type~cell2type, sum) #making the pivot table
    pivot=as.data.frame(pivot)
    pivotnorm=pivot
    last_tissue=ncol(pivot)
    
    x=rowSums(pivot[,2:last_tissue]) 
    pivotnorm[,2:last_tissue]=pivotnorm[,2:last_tissue]/x
    write.table(pivot,paste("pivotORI_",files[z],sep=""),sep=',',row.names=FALSE,col.names=TRUE,quote=FALSE)
    write.table(pivotnorm,paste("pivotNORM_",files[z],sep=""),sep=',',row.names=FALSE,col.names=TRUE,quote=FALSE)
    
  }
}
