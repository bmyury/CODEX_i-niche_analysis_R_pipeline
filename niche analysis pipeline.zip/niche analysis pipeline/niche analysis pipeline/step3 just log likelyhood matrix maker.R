counter=0
myFile = file.choose()
dira=dirname(myFile)
setwd(dira)

files=list.files(dira)

for (z in 1:length(files))
{
  if(grepl('^pivotORI_reg.*Rdelaun.csv$',files[z]))
  {
    print(files[z])
    counter=counter+1
    
    #reading input file
    input <- read.csv(files[z], header=FALSE, stringsAsFactors=FALSE)
    input=input[input[,1]!="dirt",]
    input=input[,input[1,]!="dirt"]
    rows=input[,1]
    rows=rows[-1]
    cols=input[1,]
    cols=as.character(cols)
    cols=cols[-1]
    ma=input[-1,-1]
    rownames(ma)=rows
    colnames(ma)=cols
    ma=data.matrix(ma)
    
    su=sum(ma)
    print(su)
    mano=ma/su
    hor=apply(ma,1,sum)
    hornorm=hor/su
    a=mano
    
    for (i in (1:length(mano[1,])))
    {
      for (j in (1:length(mano[1,])))
      {
        a[i,j]=mano[i,j]/(hornorm[i]*hornorm[j])
      }
    }
    
    b=cbind(rows,a)
    c=rbind(c("pairs",cols),b)
    
    write.table(c,paste("lglikelyhood_mx_from",files[z],sep='_'),row.names = FALSE,col.names = FALSE,sep = ",",quote = FALSE)
  }
}