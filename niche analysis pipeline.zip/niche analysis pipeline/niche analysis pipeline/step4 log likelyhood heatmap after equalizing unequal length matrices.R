#cluster_or_reorder="cluster"
cluster_or_reorder="reorder"

library(gplots)

myFile = file.choose()
resultscolnames=vector(mode="character", length=5)
dira=dirname(myFile)
setwd(dira)

counter=0

files=list.files(dira)

for (z in 1:length(files))
{
  if(grepl('^lglikelyhood_mx_from_pivotORI_reg00._Rdelaun.csv$',files[z]))
  {
    print(files[z])
    counter=counter+1
    
    #reading input file
    input <- read.csv(files[z], header=FALSE, stringsAsFactors=FALSE)
    rows=input[,1]
    rows=rows[-1]
    cols=input[1,]
    cols=as.character(cols)
    cols=cols[-1]
    ma=input[-1,-1]
    rownames(ma)=rows
#    colreport[,counter]=cols
#    rowreport[,counter]=rows
    colnames(ma)=cols
    ma=data.matrix(ma)
    
    a=ma
    a=as.matrix(a)
    
##################### done reading and re-formatting the matrix
      b=a
      for (i in (1:length(ma[1,])))
        {
          for (j in (1:length(ma[1,])))
          {
            b[i,j]=paste(cols[i],"___",cols[j],sep="")
          }
        }
      
#####################done making the matrix of row and column names for the interaction matrix     
      asvecb=vector(mode="character", length=0)    
      for (i in (1:length(ma[1,])))
      {
        asvecb=append(asvecb,b[i,i:length(b[1,])])
      }
      b=asvecb
##################done unfolding the row names for the upper triangle of the interaction matrix
   
    asveca=vector(mode="numeric", length=0)    
    for (i in (1:length(ma[1,])))
    {
        asveca=append(asveca,a[i,i:length(a[1,])])
     }
    a=asveca
    
  ##################done unfolding the values for the upper triangle of the interaction matrix
    if (counter==1)
    {
      combo1=data.frame(matrix(nrow = length(b), ncol = 2))  
      combo1[,2]=a
      combo1[,1]=b
      colnames(combo1)=c("annotation",files[z])
      combo=combo1
################done naming a row after file
    }
    
    if (counter>1)
    {
      combo2=data.frame(matrix(nrow = length(b), ncol = 2))  
      combo2[,2]=a
      combo2[,1]=b
      colnames(combo2)=c("annotation",files[z])
      combo=merge(combo,combo2, by="annotation",all=TRUE)
    }
    
  }
  
}
leftcell=as.character(apply(combo,1,function(x)strsplit(as.character(x[1]),"___",fixed=TRUE)[[1]][1]))
rightcell=as.character(apply(combo,1,function(x)strsplit(as.character(x[1]),"___",fixed=TRUE)[[1]][2]))
combo=cbind(leftcell,rightcell,combo)
colnames(combo)[c(1,2)]=c("leftcell","rightcell")
combox=rbind(combo,setNames(combo,c("rightcell","leftcell",colnames(combo[,3:length(combo)]))))
comboxu=unique(combox)



if (cluster_or_reorder =="reorder")

{
  print ("reordering")
  c=cast(comboxu,leftcell~rightcell,value=basename(myFile))
  rows=c[,1]
  c=c[,-1]
  rownames(c)=rows
  c=data.matrix(c[order(rows),order(rows)])
  c[is.na(c)]=1
  dd = function(c) as.dist(1/(c+5))
  hmstore=heatmap.2(c, distfun=dd)
  
  
  for (z in 1:(length(colnames(comboxu))-3))
    
  {
    c=cast(comboxu,leftcell~rightcell,value=colnames(comboxu)[3+z])
    rows=c[,1]
    c=c[,-1]
    rownames(c)=rows
    #    colreport[,counter]=cols
    #    rowreport[,counter]=rows
    
    c=data.matrix(c[order(rows),order(rows)])
    c[is.na(c)]=1
    
    
    breaks = seq(0,4,length.out=1000)
    
    gradient1 = colorpanel( sum( breaks[-1]<=1 ), "#0030FF", "white" )
    
    gradient2 = colorpanel( sum( breaks[-1]>1 ), "white", "#FF5020" )
    
    hm.colors = c(gradient1,gradient2)
    
    
    
    #    if (counter==1){
    #      palette.breaks <- seq(quantile.range["5%"], quantile.range["95%"], 0.1)
    #    }
    # use http://colorbrewer2.org/ to find optimal divergent color palette (or set own)
    #    color.palette  <- colorRampPalette(c("#5f97cf", "#FFFFFF", "#FC8D59"))(length(palette.breaks) - 1)
    

    #    dd = function(x) as.dist(x)
    pngfile=paste(colnames(comboxu)[3+z],'png',sep='.')
    png(filename=pngfile,height=1500, width=2000, res = 300, pointsize=10)
    c=c[hmstore$rowInd,hmstore$rowInd]
    heatmap.2(c, col=hm.colors, trace="none",lmat=rbind(4:3,2:1), breaks=breaks, margins=c(15,15),cexRow=0.4,cexCol=0.4,lwid=c(1.5,2.0),Colv = FALSE,Rowv = FALSE)
    dev.off()
  }
  
  
}
  


if (cluster_or_reorder=="cluster")

{
  
print ("clustering individually")

for (z in 1:(length(colnames(comboxu))-3))

{
c=cast(comboxu,leftcell~rightcell,value=colnames(comboxu)[3+z])
rows=c[,1]
c=c[,-1]
rownames(c)=rows
#    colreport[,counter]=cols
#    rowreport[,counter]=rows

c=data.matrix(c)
c[is.na(c)]=1
  
  
breaks = seq(0,4,length.out=1000)

gradient1 = colorpanel( sum( breaks[-1]<=1 ), "#0030FF", "white" )

gradient2 = colorpanel( sum( breaks[-1]>1 ), "white", "#FF5020" )

hm.colors = c(gradient1,gradient2)



#    if (counter==1){
#      palette.breaks <- seq(quantile.range["5%"], quantile.range["95%"], 0.1)
#    }
# use http://colorbrewer2.org/ to find optimal divergent color palette (or set own)
#    color.palette  <- colorRampPalette(c("#5f97cf", "#FFFFFF", "#FC8D59"))(length(palette.breaks) - 1)

dd = function(c) as.dist(1/(c+5))
#    dd = function(x) as.dist(x)
pngfile=paste(colnames(comboxu)[3+z],'png',sep='.')
png(filename=pngfile,height=1500, width=2000, res = 300, pointsize=10)
#hmstore=heatmap.2(a, distfun=dd)

#heatmap.2(a, distfun=dd,col=hm.colors, trace="none",lmat=rbind(4:3,2:1), breaks=breaks, margins=c(15,15),cexRow=0.7,cexCol=0.7,lwid=c(1.5,2.0),Colv = FALSE,Rowv = FALSE)
heatmap.2(c, distfun=dd,col=hm.colors, trace="none",lmat=rbind(4:3,2:1), breaks=breaks, margins=c(15,15),cexRow=0.4,cexCol=0.4,lwid=c(1.5,2.0))
dev.off()
}
}



#combo[is.na(combo)]=0

#write.table(combo,"lglikelyhoods_UPPERtr.csv",sep=',',row.names=TRUE,col.names=TRUE,quote=FALSE)
