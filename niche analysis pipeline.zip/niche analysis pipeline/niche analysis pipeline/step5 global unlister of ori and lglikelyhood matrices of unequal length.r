library(reshape)

myFile = file.choose()
resultscolnames=vector(mode="character", length=5)
dira=dirname(myFile)
setwd(dira)

counter=0

files=list.files(dira)

#making the matrix of cell counts per region
cell_counts=cast(essentialfulldata,annot~Comment)
#done making the matrix of cell counts per region


tissues=colnames(cell_counts[,-1])

for (z in 1:length(tissues))
{

    print(tissues[z])
    counter=counter+1
    
    #reading lglilyhd_input file
    lglklyhd_input <- read.csv(paste("lglikelyhood_mx_from_pivotORI",tissues[z],"Rdelaun.csv",sep="_"), header=FALSE, stringsAsFactors=FALSE)
    rows=lglklyhd_input[,1]
    rows=rows[-1]
    cols=lglklyhd_input[1,]
    cols=as.character(cols)
    cols=cols[-1]
    lglklyhd_ma=lglklyhd_input[-1,-1]
    rownames(lglklyhd_ma)=rows
#    colreport[,counter]=cols
#    rowreport[,counter]=rows
    colnames(lglklyhd_ma)=cols
    lglklyhd_ma=data.matrix(lglklyhd_ma)
    lglklyhd_a=lglklyhd_ma
    lglklyhd_a=as.matrix(lglklyhd_a)
    
    
    ori_intcount_input <- read.csv(paste("pivotORI",tissues[z],"Rdelaun.csv",sep="_"), header=FALSE, stringsAsFactors=FALSE)
    rows=ori_intcount_input[,1]
    rows=rows[-1]
    cols=ori_intcount_input[1,]
    cols=as.character(cols)
    cols=cols[-1]
    ori_intcount_ma=ori_intcount_input[-1,-1]
    rownames(ori_intcount_ma)=rows
    #    colreport[,counter]=cols
    #    rowreport[,counter]=rows
    colnames(ori_intcount_ma)=cols
    ori_intcount_ma=data.matrix(ori_intcount_ma)
    ori_intcount_a=ori_intcount_ma
    ori_intcount_a=as.matrix(ori_intcount_a)
##################### done reading and re-formatting the matrix
    
####initializing the matrices for cell to cell names and cell counts of right and left cell##
      b=ori_intcount_a
      leftcell=ori_intcount_a
      rightcell=ori_intcount_a
####done initializing the matrices for cell to cell names and cell counts of right and left cell##
      
####filling the matrices for cell to cell names and cell counts of right and left cell##      
      for (i in (1:length(ori_intcount_a[1,])))
        {
          for (j in (1:length(ori_intcount_a[1,])))
          {
            b[i,j]=paste(cols[i],"___",cols[j],sep="")
            leftcell[i,j]=cell_counts[cell_counts[,1]==cols[i],tissues[z]]
            rightcell[i,j]=cell_counts[cell_counts[,1]==cols[j],tissues[z]]
          }
      }
####done filling the matrices for cell to cell names and cell counts of right and left cell##
      
      
#####################unfolding the upper traingle of names and cell counts     
      asvecb=vector(mode="character", length=0)    
      for (i in (1:length(ori_intcount_a[1,])))
      {
        asvecb=append(asvecb,b[i,i:length(b[1,])])
      }
      
      asvec_leftcell=vector(mode="numeric", length=0)    
      for (i in (1:length(ori_intcount_a[1,])))
      {
        asvec_leftcell=append(asvec_leftcell,leftcell[i,i:length(leftcell[1,])])
      }
      
      asvec_rightcell=vector(mode="numeric", length=0)    
      for (i in (1:length(ori_intcount_a[1,])))
      {
        asvec_rightcell=append(asvec_rightcell,rightcell[i,i:length(rightcell[1,])])
      }
##################done unfolding the upper traingle of names and cell counts
   
    asvec_ori_intcount_a=vector(mode="numeric", length=0)    
    for (i in (1:length(ori_intcount_a[1,])))
    {
        asvec_ori_intcount_a=append(asvec_ori_intcount_a,ori_intcount_a[i,i:length(ori_intcount_a[1,])])
    }
    
    asvec_lglklyhd_a=vector(mode="numeric", length=0)    
    for (i in (1:length(lglklyhd_a[1,])))
    {
      asvec_lglklyhd_a=append(asvec_lglklyhd_a,lglklyhd_a[i,i:length(lglklyhd_a[1,])])
    }

    
  ##################done unfolding the values for the upper triangle of the interaction matrix
    if (counter==1)
    {
      combo1=data.frame(matrix(nrow = length(asvecb), ncol = 5))  
      
      combo1[,1]=asvecb
      combo1[,2]=asvec_leftcell
      combo1[,3]=asvec_rightcell
      combo1[,4]=asvec_ori_intcount_a
      combo1[,5]=asvec_lglklyhd_a
      colnames(combo1)=c("annotation",paste(tissues[z],"leftcell_count",sep="_"),paste(tissues[z],"rightcell_count",sep="_"),paste(tissues[z],"ori_int_count",sep="_"),paste(tissues[z],"likelyhood_ratio",sep="_"))
      combo=combo1
################done naming a row after file
    }
    
    if (counter>1)
    {
      combo2=data.frame(matrix(nrow = length(asvecb), ncol = 5))  
      
      combo2[,1]=asvecb
      combo2[,2]=asvec_leftcell
      combo2[,3]=asvec_rightcell
      combo2[,4]=asvec_ori_intcount_a
      combo2[,5]=asvec_lglklyhd_a
      colnames(combo2)=c("annotation",paste(tissues[z],"leftcell_count",sep="_"),paste(tissues[z],"rightcell_count",sep="_"),paste(tissues[z],"ori_int_count",sep="_"),paste(tissues[z],"likelyhood_ratio",sep="_"))
      combo=merge(combo,combo2, by="annotation",all=TRUE)
    }
  
}

#combo[is.na(combo)]=0
#combo=combo[,c(1,2,6,10,14,3,7,11,15,4,8,12,16,5,9,13,17)]
#combo=combo[,c(1,2,4,3,5,6,8,7,9,10,12,11,13,14,16,15,17)]
write.table(combo,"new_full_pairwise_analysis_UPPERtr.csv",sep=',',row.names=FALSE,col.names=TRUE,quote=FALSE)
