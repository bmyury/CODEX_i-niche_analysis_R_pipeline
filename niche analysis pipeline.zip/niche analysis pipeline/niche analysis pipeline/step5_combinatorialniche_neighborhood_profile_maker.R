library(reshape)

myFile = file.choose()
resultscolnames=vector(mode="character", length=5)
dira=dirname(myFile)
setwd(dira)

counter=0

files=list.files(dira)

for (z in 1:length(files))
{
  if(grepl('^reg00._Rdelaun.csv$',files[z]))
  {
    input <- read.csv(files[z], stringsAsFactors=FALSE)
    regionid=strsplit(files[z],"_")[[1]][1]
    print(regionid)
    input=as.data.frame(input)
    input[,7]=paste(regionid,input[,1],input[,2],sep="-")
    input[,8]=1
    profiles=cast(input,V7~cell2type,value="V8")
    rownames(profiles)=profiles[,1]
    profiles=profiles[,-1]
    profiles_norm=profiles/rowSums(profiles)
    write.table(profiles_norm,paste(regionid,"_neighborprofiles.csv",sep=""),sep=",",row.names = TRUE,col.names = NA, quote = FALSE)
  }
}