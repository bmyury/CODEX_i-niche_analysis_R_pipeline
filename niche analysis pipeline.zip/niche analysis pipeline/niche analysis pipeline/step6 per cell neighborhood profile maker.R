library(readr)
reg001_Rdelaun <- read_csv("H:/Saulius_new_1_processed/Saulius1_analytics/reg001_Rdelaun.csv")
reg002_Rdelaun <- read_csv("H:/Saulius_new_1_processed/Saulius1_analytics/reg002_Rdelaun.csv")
reg003_Rdelaun <- read_csv("H:/Saulius_new_1_processed/Saulius1_analytics/reg003_Rdelaun.csv")
reg004_Rdelaun <- read_csv("H:/Saulius_new_1_processed/Saulius1_analytics/reg004_Rdelaun.csv")

reg001_Rdelaun=as.data.frame(reg001_Rdelaun)
reg001_Rdelaun[,7]=paste("reg001",reg001_Rdelaun[,1],reg001_Rdelaun[,2],sep="-")
reg001_Rdelaun[,8]=1
reg001nbrprofiles=cast(reg001_Rdelaun,V7~cell2type,value="V8")
rownames(reg001nbrprofiles)=reg001nbrprofiles[,1]
reg001nbrprofiles=reg001nbrprofiles[,-1]
reg001nbrprofiles_norm=reg001nbrprofiles/rowSums(reg001nbrprofiles)
write.table(reg001nbrprofiles_norm,"reg001_neighborprofiles.csv",sep=",",row.names = TRUE,col.names = NA, quote = FALSE)


reg002_Rdelaun=as.data.frame(reg002_Rdelaun)
reg002_Rdelaun[,7]=paste("reg002",reg002_Rdelaun[,1],reg002_Rdelaun[,2],sep="-")
reg002_Rdelaun[,8]=1
reg002nbrprofiles=cast(reg002_Rdelaun,V7~cell2type,value="V8")
rownames(reg002nbrprofiles)=reg002nbrprofiles[,1]
reg002nbrprofiles=reg002nbrprofiles[,-1]
reg002nbrprofiles_norm=reg002nbrprofiles/rowSums(reg002nbrprofiles)
write.table(reg002nbrprofiles_norm,"reg002_neighborprofiles.csv",sep=",",row.names = TRUE,col.names = NA, quote = FALSE)

reg004_Rdelaun=as.data.frame(reg004_Rdelaun)
reg004_Rdelaun[,7]=paste("reg004",reg004_Rdelaun[,1],reg004_Rdelaun[,2],sep="-")
reg004_Rdelaun[,8]=1
reg004nbrprofiles=cast(reg004_Rdelaun,V7~cell2type,value="V8")
rownames(reg004nbrprofiles)=reg004nbrprofiles[,1]
reg004nbrprofiles=reg004nbrprofiles[,-1]
reg004nbrprofiles_norm=reg004nbrprofiles/rowSums(reg004nbrprofiles)
write.table(reg004nbrprofiles_norm,"reg004_neighborprofiles.csv",sep=",",row.names = TRUE,col.names = NA, quote = FALSE)

reg003_Rdelaun=as.data.frame(reg003_Rdelaun)
reg003_Rdelaun[,7]=paste("reg003",reg003_Rdelaun[,1],reg003_Rdelaun[,2],sep="-")
reg003_Rdelaun[,8]=1
reg003nbrprofiles=cast(reg003_Rdelaun,V7~cell2type,value="V8")
rownames(reg003nbrprofiles)=reg003nbrprofiles[,1]
reg003nbrprofiles=reg003nbrprofiles[,-1]
reg003nbrprofiles_norm=reg003nbrprofiles/rowSums(reg003nbrprofiles)
write.table(reg003nbrprofiles_norm,"reg003_neighborprofiles.csv",sep=",",row.names = TRUE,col.names = NA, quote = FALSE)
