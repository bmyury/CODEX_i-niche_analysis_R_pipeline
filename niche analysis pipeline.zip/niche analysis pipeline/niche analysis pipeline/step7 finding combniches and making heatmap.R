library(RColorBrewer)
library(gplots)
library(ggplot2)
library(reshape)

myFile = file.choose()
resultscolnames=vector(mode="character", length=5)
dira=dirname(myFile)
setwd(dira)



counter=0

files=list.files(dira)

for (z in 1:length(files))
{
  if(grepl('^reg00._neighborprofiles.csv$',files[z]))
  {
    counter=counter+1
    input <- read.csv(files[z], stringsAsFactors=FALSE)
    rownames(input)=input[,1]
    input=input[,-1]
    print(files[z])
    print(dim(input))
    if (counter==1)
    {combo=input}
    if (counter>1)
    {combo=rbind(combo,input)}
  }
  
}

a=kmeans(combo,100,iter.max = 100)

c=a$centers
b=a$cluster
b=as.data.frame(b)
b[,2]=rownames(b)
colnames(b)[2]="cellid"
xx=paste(essentialfulldata[,3],essentialfulldata[,4],essentialfulldata[,5],sep="-")
essentialfulldata[,7]=xx
colnames(essentialfulldata)[7]="cellid"
xxb=merge(essentialfulldata,b,by="cellid")

quantile.range <- quantile(as.numeric(c), probs = seq(0, 1, 0.01))
palette.breaks <- seq(quantile.range["5%"], quantile.range["98%"], (quantile.range["98%"]- quantile.range["5%"])/1000)

## use http://colorbrewer2.org/ to find optimal divergent color palette (or set own)
color.palette  <- colorRampPalette(c("black","blue","green"))(length(palette.breaks) - 1)

pngfile=paste("niches",'png',sep='.')
#pdffile=paste(cleaned_marker,'pdf',sep='.')
png(filename=pngfile,height=1100, width=2000, res = 300, pointsize=10)
#pdf(pdffile,height=4, width=8, pointsize=10)

#print(uniquecelltypes[z])

d=t(c)

heatmap.2(d, labCol=colnames(d),dendrogram="none",col=color.palette, trace="none", breaks=palette.breaks, margins=c(3,20),cexRow=0.7,cexCol=0.5)
dev.off()

d=d[,order(as.numeric(colnames(d)))]
nichemap=heatmap.2(d, labCol=colnames(d),dendrogram="none",col=color.palette, trace="none", breaks=palette.breaks, margins=c(3,20),cexRow=0.7,cexCol=0.5)

nicheorder=nichemap$colInd
cellorder=nichemap$rowInd

d=d[,nicheorder]
d=d[cellorder,]
d=d[dim(d)[1]:1,]

per_region_niches=xxb[,c(4,7,8)]
per_region_niches[,4]=1
cells_in_niches=cast(per_region_niches,Comment+annot~nichename)
cells_in_niches=as.data.frame(cells_in_niches)
cells_in_niches=cells_in_niches[,c(1,2,2+nicheorder)]
cells_in_niches_numeral=cells_in_niches[,3:ncol(cells_in_niches)]
cells_in_niches_norm=cells_in_niches
cells_in_niches_norm[,3:ncol(cells_in_niches)]=cells_in_niches_numeral/rowSums(cells_in_niches_numeral)
write.table(cells_in_niches,paste(regions[i],"_cells_in_niches.cst",sep = ""),row.names = TRUE,col.names = NA,quote = FALSE,sep = ",")
write.table(cells_in_niches_norm,paste(regions[i],"_cells_in_niches_norm.cst",sep = ""),row.names = TRUE,col.names = NA,quote = FALSE,sep = ",")

celltypes=unique(cells_in_niches_norm[,2])

for (index in 1:length(celltypes))
{
  addon=cells_in_niches_norm[cells_in_niches_norm[,2]==celltypes[index],]
  rownames(addon)=addon[,1]
  addon=addon[,3:ncol(addon)]
  addon=as.matrix(addon)
  kaugm=rbind(d,5*addon)
  color.palette  <- colorRampPalette(c("black","green","red"))(100)
  #pdf(paste(strsplit(rownames(cells_in_WTniches_norm)[index],"__",fixed=TRUE)[[1]][1],"__.pdf",sep=""),height=5, width=8, pointsize=8)
  png(paste(gsub("[[:punct:]]", " ", rownames(cells_in_WTniches_norm)[index]),"__.png",sep=""),height=1000, width=2000, res = 300, pointsize=10)
  heatmap.2(kaugm,Rowv=FALSE,Colv=FALSE, dendrogram="none",col=color.palette, trace="none", margins=c(3,20),cexRow=0.3,cexCol=0.3)
  dev.off()
}

